﻿// Adam Majchrzak s176708 05.05.2020
//

#include <iostream>
#include <vector>
#include <fstream>

void fill_vector(std::vector<double>& z, int n) {
    double value;

    for (int i = 0; i < n; ++i) {
        std::cin >> value;
        z.push_back(value);
    }
}

void print_vector(std::vector<double> z) {
    for (int i = 0; i < z.size(); ++i) {
        std::cout << z[i] << " ";
    }
    std::cout << std::endl;
}


int main()
{
    std::cout << "Mamy macierz trojdiagonalna\n";
    int n;
    std::cout << "Wpisz ile wymiarow ma miec macierz (rozwazamy macierze kwadratowe wiec wystarczy 1 cyfra))?\n";
    std::cin >> n;
    std::vector<double> a;
    std::vector<double> b;
    std::vector<double> c;
    std::vector<double> d;
    std::vector<double> beta;
    std::vector<double> gamma;
    std::vector<double> x;
    //uzupelnij vectory
    std::cout << "Wprowadz dane do przekatnej a ktora znajduje sie pod diagonala.\n";
    fill_vector(a,n);
    std::cout << "Wprowadz dane do przekatnej b ktora znajduje sie nad diagonala.\n";
    fill_vector(b,n);
    std::cout << "Wprowadz dane do przekatnej c ktora jest diagonala.\n";
    fill_vector(c,n);
    std::cout << "Wprowadz dane do macierzy wynikowej d\n";
    fill_vector(d,n);
    //pokaz vectory
    a[0] = 0;
    c[n-1] = 0;
    std::cout << "Nasze wektory: \n";
    std::cout << "a: ";
    print_vector(a);
    std::cout << "\nb: ";
    print_vector(b);
    std::cout << "\nc: ";
    print_vector(c);
    std::cout << "\nd: ";
    print_vector(d);
    double val = 0;
    //double val1 = 0;
    val = -c[0] / b[0];
    beta.push_back(val);
    for (int i = 1; i < n; ++i) {
        val = -(c[i] / ((a[i] * beta[i-1]) + b[i]));
        if (val == -0) val = 0; //warunek dla poprawnosci zapisu (nie może być -0)
        beta.push_back(val);
    }
    std::cout << "\nObliczona beta z naszych danych 1 do n: ";
    print_vector(beta);
    
    double val2 = 0;
    val2 = d[0] / b[0];
    gamma.push_back(val2);
    for (int i = 1; i < n; ++i) {
        val2 = (d[i] - a[i] * gamma[i - 1]) / (a[i] * beta[i - 1] + b[i]);
        gamma.push_back(val2);
    }
    std::cout << "\nObliczona gamma z naszych danych od 1 do n: ";
    print_vector(gamma);
    

    double val1 = 0;
    x.push_back(gamma[n-1]);
    int j = 0;
    for (int i = n; i > 1; --i) {
        val1 = (beta[i - 2] * x[j]) + (gamma[i - 2]);
        x.push_back(val1);
        j++;
    }
    std::cout << "\nNasze x w kolejnosci: xn,xn-1, ... x3,x2,x1: ";
    print_vector(x);
}

